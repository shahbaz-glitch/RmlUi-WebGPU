#pragma once

#include "Debug.h"
#include "Math.h"

namespace Rml {

/**
    Templated class for a generic three-component vector.
 */

template <typename Type>
class Vector3 {
public:
	/// Default constructor.
	inline Vector3();
	/// Initialising constructor.
	/// @param[in] v Initial value of each element in the vector.
	explicit inline Vector3(Type v);
	/// Initialising constructor.
	/// @param[in] x Initial x-value of the vector.
	/// @param[in] y Initial y-value of the vector.
	/// @param[in] z Initial z-value of the vector.
	inline Vector3(Type x, Type y, Type z);

	/// Returns the magnitude of the vector.
	/// @return The computed magnitude.
	inline float Magnitude() const;
	/// Returns the squared magnitude of the vector.
	/// @return The computed squared magnitude.
	inline Type SquaredMagnitude() const;
	/// Generates a normalised vector from this vector.
	/// @return The normalised vector.
	inline Vector3 Normalise() const;

	/// Computes the dot-product between this vector and another.
	/// @param[in] rhs The other vector to use in the dot-product.
	/// @return The computed dot-product between the two vectors.
	inline Type DotProduct(const Vector3& rhs) const;

	/// Computes the cross-product between this vector and another.
	/// @param[in] rhs The other vector to use in the dot-product.
	/// @return The computed cross-product between the two vectors.
	inline Vector3 CrossProduct(const Vector3& rhs) const;

	/// Returns the negation of this vector.
	/// @return The negation of this vector.
	inline Vector3 operator-() const;

	/// Returns the sum of this vector and another.
	/// @param[in] rhs The vector to add this to.
	/// @return The sum of the two vectors.
	inline Vector3 operator+(const Vector3& rhs) const;
	/// Returns the result of subtracting another vector from this vector.
	/// @param[in] rhs The vector to subtract from this vector.
	/// @return The result of the subtraction.
	inline Vector3 operator-(const Vector3& rhs) const;
	/// Returns the result of multiplying this vector by a scalar.
	/// @param[in] rhs The scalar value to multiply by.
	/// @return The result of the scale.
	inline Vector3 operator*(Type rhs) const;
	/// Returns the result of dividing this vector by a scalar.
	/// @param[in] rhs The scalar value to divide by.
	/// @return The result of the scale.
	inline Vector3 operator/(Type rhs) const;

	/// Adds another vector to this in-place.
	/// @param[in] rhs The vector to add.
	/// @return This vector, post-operation.
	inline Vector3& operator+=(const Vector3& rhs);
	/// Subtracts another vector from this in-place.
	/// @param[in] rhs The vector to subtract.
	/// @return This vector, post-operation.
	inline Vector3& operator-=(const Vector3& rhs);
	/// Scales this vector in-place.
	/// @param[in] rhs The value to scale this vector's components by.
	/// @return This vector, post-operation.
	inline Vector3& operator*=(const Type& rhs);
	/// Scales this vector in-place by the inverse of a value.
	/// @param[in] rhs The value to divide this vector's components by.
	/// @return This vector, post-operation.
	inline Vector3& operator/=(const Type& rhs);

	/// Equality operator.
	/// @param[in] rhs The vector to compare this against.
	/// @return True if the two vectors are equal, false otherwise.
	inline bool operator==(const Vector3& rhs) const;
	/// Inequality operator.
	/// @param[in] rhs The vector to compare this against.
	/// @return True if the two vectors are not equal, false otherwise.
	inline bool operator!=(const Vector3& rhs) const;

	/// Constant auto-cast operator.
	/// @return A pointer to the first value.
	inline operator const Type*() const;
	/// Auto-cast operator.
	/// @return A constant pointer to the first value.
	inline operator Type*();

	/// Underlying type-cast operator.
	/// @return A copy of the vector with another underlying type.
	template <typename U>
	explicit inline operator Vector3<U>() const;

	// Cast to Vector2
	explicit inline operator Vector2<Type>() const;

	// The components of the vector.
	Type x;
	Type y;
	Type z;

#if defined(RMLUI_VECTOR3_USER_EXTRA)
	RMLUI_VECTOR3_USER_EXTRA
#elif defined(RMLUI_VECTOR3_USER_INCLUDE)
	#include RMLUI_VECTOR3_USER_INCLUDE
#endif
};

} // namespace Rml

#include "Vector3.inl"
